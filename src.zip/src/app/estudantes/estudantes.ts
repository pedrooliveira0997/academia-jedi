export interface IEstudante {
    id: number;
    nome: string;
    altura: String;
    peso: String;
    corCabelo: String;
    corOlhos: string;
    anoNascimento: String;
    sexo: string;
    planeta: String;
    url: String
}