import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'jedi-bem-vindo',
  template: 
    '<h1>Seja Bem Vindo a Academia Jedi!!!</h1>',
  //templateUrl: './bem-vindo.component.html',
  //styleUrls: ['./bem-vindo.component.css']
})
export class BemVindoComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
